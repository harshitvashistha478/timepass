"""
EnquirySession tracks every query that came through the Enquiry Department:
what was decided, why, and which hub session(s) were spawned.

research_session_id and dev_session_id are plain string references
(not FK-constrained) so the same table works no matter how many hubs are added.
When you add a new hub, add a nullable column here for its session id.
"""

import uuid
from datetime import datetime
from sqlalchemy import String, DateTime, ForeignKey, Text, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship
import enum as py_enum

from app.core.database import Base


class EnquiryStatus(str, py_enum.Enum):
    pending    = "pending"
    routing    = "routing"
    dispatched = "dispatched"   # hub tasks fired; they run independently
    failed     = "failed"


class EnquirySession(Base):
    __tablename__ = "enquiry_sessions"

    id:         Mapped[str]           = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id:    Mapped[str]           = mapped_column(String, ForeignKey("users.id"))
    query:      Mapped[str]           = mapped_column(Text, nullable=False)
    status:     Mapped[EnquiryStatus] = mapped_column(Enum(EnquiryStatus), default=EnquiryStatus.pending)

    # Routing result
    routing_decision: Mapped[str | None] = mapped_column(Text, nullable=True)   # JSON list, e.g. '["research","developer"]'
    reasoning:        Mapped[str | None] = mapped_column(Text, nullable=True)

    # Hub session references (add a column here for each new hub)
    research_session_id: Mapped[str | None] = mapped_column(String, nullable=True)
    dev_session_id:      Mapped[str | None] = mapped_column(String, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped["User"] = relationship(back_populates="enquiry_sessions")  # type: ignore
